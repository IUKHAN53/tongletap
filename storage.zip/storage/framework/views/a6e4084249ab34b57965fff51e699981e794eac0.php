<?php $__env->startPush('script-page'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page-title'); ?>
<?php echo e(__('Manage Ticket')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<div class="d-inline-block">
    <h5 class="h4 d-inline-block font-weight-400 mb-0 "><?php echo e(__('Manage Ticket')); ?></h5>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
<li class="breadcrumb-item"><?php echo e(__('Manage Ticket')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('action-btn'); ?>
<div class="float-end">
    <!-- <a href="<?php echo e(route('support.grid')); ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="<?php echo e(__('Grid View')); ?>">
        <i class="ti ti-layout-grid text-white"></i>
    </a> -->

    <a href="#" data-url="<?php echo e(route('ticket.create')); ?>" data-ajax-popup="true" data-title="<?php echo e(__('Create New Ticket')); ?>" data-size="lg" data-bs-toggle="tooltip" title="" class="btn btn-sm btn-primary" data-bs-original-title="<?php echo e(__('Create')); ?>">
        <i class="ti ti-plus"></i>
    </a>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mb-3 mb-sm-0">
                        <div class="d-flex align-items-center">
                            <div class="theme-avtar bg-primary">
                                <i class="ti ti-cast"></i>
                            </div>
                            <div class="ms-3">
                                <h6 class="m-0"><?php echo e(__('Ticket Request')); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto text-end">
                        <h3 class="m-0"><?php echo e($countTicket); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mb-3 mb-sm-0">
                        <div class="d-flex align-items-center">
                            <div class="theme-avtar bg-info">
                                <i class="ti ti-cast"></i>
                            </div>
                            <div class="ms-3">
                                <h6 class="m-0"><?php echo e(__('Pending Ticket')); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto text-end">
                        <h3 class="m-0"><?php echo e($countPendingTicket); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mb-3 mb-sm-0">
                        <div class="d-flex align-items-center">
                            <div class="theme-avtar bg-warning">
                                <i class="ti ti-cast"></i>
                            </div>
                            <div class="ms-3">
                                <h6 class="m-0"><?php echo e(__('Approved Ticket')); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto text-end">
                        <h3 class="m-0"><?php echo e($countApprovedTicket); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mb-3 mb-sm-0">
                        <div class="d-flex align-items-center">
                            <div class="theme-avtar bg-danger">
                                <i class="ti ti-cast"></i>
                            </div>
                            <div class="ms-3">
                                <h6 class="m-0"><?php echo e(__('Rejected Ticket')); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto text-end">
                        <h3 class="m-0"><?php echo e($countRejectedTicket); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body table-border-style">
                <div class="table-responsive">
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Title')); ?></th>
                                <th><?php echo e(__('Ticket Request Code')); ?></th>
                                <?php if(\Auth::user()->type <> 'employee'): ?>
                                    <th><?php echo e(__('Employee')); ?></th>
                                    <th><?php echo e(__('Employee Phone')); ?></th>
                                    <th><?php echo e(__('Company Name')); ?></th>
                                    <?php endif; ?>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th><?php echo e(__('priority')); ?></th>
                                    <th><?php echo e(__('Appointment Time and Day')); ?></th>
                                    <th><?php echo e(__('Created By')); ?></th>
                                    <th><?php echo e(__('Description')); ?></th>
                                    <th width="200px"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>

                        <tbody class="list">

                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span style="display: block;
                                            white-space: nowrap;
                                            width: 150px;
                                            overflow: hidden;
                                            text-overflow: ellipsis;"><?php echo e($ticket->title); ?></span>
                                </td>
                                <td><?php echo e($ticket->ticket_code); ?></td>
                                <?php if(\Auth::user()->type <> 'employee'): ?>
                                    <!-- $user = \Auth::user()->getUser($ticket->employee_id); -->
                                    <?php
                                    $user = \Auth::user();
                                    ?>

                                    <td><?php echo e($ticket->employee_name); ?></td>
                                    <td><?php echo e($ticket->employee_phone); ?></td>
                                    <td><?php echo e($ticket->company_name); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <?php if($ticket->status == 'pending'): ?>
                                        <div class="badge bg-info p-2 rounded status-badde3"><?php echo e(__('Pending')); ?></div>
                                        <?php elseif($ticket->status == 'approved'): ?>
                                        <div class="badge bg-warning p-2 rounded status-badde3"><?php echo e(__('Approved')); ?></div>
                                        <?php elseif($ticket->status == 'rejected'): ?>
                                        <div class="badge bg-danger p-2 rounded status-badde3"><?php echo e(__('Rejected')); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($ticket->priority); ?></td>
                                    <td><?php echo e(date('M j, Y H:i', strtotime($ticket->time_slot))); ?></td>
                                    <td><?php echo e(!empty($ticket->createdBy) ? $ticket->createdBy->name : ''); ?></td>
                                    <td>
                                        <span style="display: block;
                                            white-space: nowrap;
                                            width: 200px;
                                            overflow: hidden;
                                            text-overflow: ellipsis;"><?php echo e($ticket->description); ?></span>
                                    </td>
                                    <td class="Action">
                                        <?php if(\Auth::user()->type == 'super admin'): ?>
                                        <div class="action-btn bg-warning ms-2">
                                            <a href="#" data-url="<?php echo e(URL::to('ticket/' . $ticket->id . '/edit-status')); ?>" data-ajax-popup="true" data-title="<?php echo e(__('Change Ticket Status')); ?>" data-size="lg" data-bs-toggle="tooltip" title="" class="mx-3 btn btn-sm align-items-center" data-bs-original-title="<?php echo e(__('Change Ticket Status')); ?>">
                                                <i class="ti ti-info-square text-white"></i>
                                            </a>
                                        </div>
                                        <?php endif; ?>
                                        <div class="action-btn bg-primary ms-2">
                                            <a href="<?php echo e(URL::to('ticket/' . $ticket->id . '/reply')); ?>" class="mx-3 btn btn-sm align-items-center" data-bs-toggle="tooltip" title="" data-title="<?php echo e(__('Reply')); ?>" data-bs-original-title="<?php echo e(__('Reply')); ?>">
                                                <i class="ti ti-arrow-back-up text-white"></i>
                                            </a>
                                        </div>

                                        <!-- <?php if(\Auth::user()->type == 'company' || $ticket->ticket_created == \Auth::user()->id): ?>
                                                     below code
                                        <?php endif; ?> -->

                                        <div class="action-btn bg-info ms-2">
                                            <a href="#" data-url="<?php echo e(URL::to('ticket/' . $ticket->id . '/edit')); ?>" data-ajax-popup="true" data-title="<?php echo e(__('Edit Ticket')); ?>" data-size="lg" data-bs-toggle="tooltip" title="" class="mx-3 btn btn-sm align-items-center" data-bs-original-title="<?php echo e(__('Edit')); ?>">
                                                <i class="ti ti-pencil text-white"></i>
                                            </a>
                                        </div>
                                        <div class="action-btn bg-danger ms-2">
                                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['ticket.destroy', $ticket->id], 'id' => 'delete-form-' . $ticket->id]); ?>

                                            <a href="#" class="mx-3 btn btn-sm align-items-center bs-pass-para" data-bs-toggle="tooltip" title="" data-bs-original-title="Delete" aria-label="Delete">
                                                <i class="ti ti-trash text-white"></i>
                                            </a>
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tongle\resources\views/ticket/index.blade.php ENDPATH**/ ?>