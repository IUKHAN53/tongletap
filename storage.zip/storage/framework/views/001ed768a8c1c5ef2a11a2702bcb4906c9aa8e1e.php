<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Verify Email')); ?>

<?php $__env->stopSection(); ?>
<?php
  //  $logo=asset(Storage::url('uploads/logo/'));
    $logo=\App\Models\Utility::get_file('uploads/logo');
 $company_logo=Utility::getValByName('company_logo');
?>
<?php $__env->startSection('auth-topbar'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="">
        <h2 class="mb-3 f-w-600"><?php echo e(__('Verify Your Email Address')); ?></h2>
        <?php if(session('resent')): ?>
            <p class="mb-4 text-muted">
                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

            </p>
        <?php endif; ?>
        <small class="text-muted"><?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

            <?php echo e(__('If you did not receive the email')); ?>,
        </small>
        <small>
            <a href="<?php echo e(route('verification.resend')); ?>" class="text-primary"><?php echo e(__('click here to request another.')); ?></a>
        </small>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tongle\resources\views\auth\verify.blade.php ENDPATH**/ ?>