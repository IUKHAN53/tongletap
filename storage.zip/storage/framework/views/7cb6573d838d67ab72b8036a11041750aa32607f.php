<?php echo e(Form::model($ticket, ['route' => ['ticket.update', $ticket->id], 'method' => 'PUT'])); ?>

<div class="modal-body">
    <div class="row">
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('title', __('Subject'), ['class' => 'col-form-label'])); ?>

                <?php echo e(Form::text('title', null, ['class' => 'form-control', 'placeholder' => __('Enter Ticket Subject')])); ?>

            </div>
        </div>
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('CompanyName', __('Company Name'), ['class' => 'col-form-label'])); ?>

                <input type="text" class="form-control" name="CompanyName" id="CompanyName" value="<?php echo e($ticket->company_name); ?>">
            </div>
        </div>
    </div>
    <?php if(\Auth::user()->type != 'employee'): ?>
    <div class="row">
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('employee_id', __('Ticket for Employee'), ['class' => 'col-form-label'])); ?>

                <?php echo e(Form::select('employee_id', $employees, null, ['class' => 'form-control select2 employee_id'])); ?>

            </div>
        </div>
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('EmployeePhone', __('Employee Phone'), ['class' => 'col-form-label'])); ?>

                <input type="number" class="form-control" name="EmployeePhone" id="EmployeePhone" value="<?php echo e($ticket->employee_phone); ?>">
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('priority', __('Priority'), ['class' => 'col-form-label'])); ?>

                <select name="priority" class="form-control select2" id="choices-multiple">
                    <option value="low" <?php if($ticket->priority == 'low'): ?> selected <?php endif; ?>><?php echo e(__('Low')); ?>

                    </option>
                    <option value="medium" <?php if($ticket->priority == 'medium'): ?> selected <?php endif; ?>><?php echo e(__('Medium')); ?>

                    </option>
                    <option value="high" <?php if($ticket->priority == 'high'): ?> selected <?php endif; ?>><?php echo e(__('High')); ?>

                    </option>
                    <option value="critical" <?php if($ticket->priority == 'critical'): ?> selected <?php endif; ?>>
                        <?php echo e(__('critical')); ?>

                    </option>
                </select>
            </div>
        </div>
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('time_slot', __('Time Slot'), ['class' => 'col-form-label'])); ?>

                <input type="datetime-local" class="form-control" name="time_slot" id="datetimepicker">
            </div>
        </div>
    </div>
    <div class="form-group">
        <?php echo e(Form::label('description', __('Description'), ['class' => 'col-form-label'])); ?>

        <?php echo e(Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => __('Ticket Description'),'rows'=>'5'])); ?>

    </div>
</div>
<div class="modal-footer">
    <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">
    <input type="submit" value="<?php echo e(__('Update')); ?>" class="btn  btn-primary">
</div>
<?php echo e(Form::close()); ?><?php /**PATH E:\www\tongle\resources\views/ticket/edit.blade.php ENDPATH**/ ?>