<?php
    $companyName = request()->query('company_name', '');
    $employeeName = request()->query('employee_name', '');
?>
<div class="card sticky-top" style="top:30px">
    <div class="list-group list-group-flush" id="useradd-sidenav">
        <a href="<?php echo e(route('health.index', ['company_name' => $companyName, 'employee_name' => $employeeName])); ?>" class="list-group-item list-group-item-action border-0 <?php echo e((Request::route()->getName() == 'health.index' ) ? ' active' : ''); ?>"><?php echo e(__('Blood Pressure')); ?> <div class="float-end"><i class="ti ti-chevron-right"></i></div></a>

        <a href="<?php echo e(route('glucose.index', ['company_name' => $companyName, 'employee_name' => $employeeName])); ?>" class="list-group-item list-group-item-action border-0 <?php echo e((Request::route()->getName() == 'glucose.index' ) ? ' active' : ''); ?>"><?php echo e(__('Glucose')); ?><div class="float-end"><i class="ti ti-chevron-right"></i></div></a>

        <a href="<?php echo e(route('exercise.index', ['company_name' => $companyName, 'employee_name' => $employeeName])); ?>" class="list-group-item list-group-item-action border-0 <?php echo e((Request::route()->getName() == 'exercise.index' ) ? ' active' : ''); ?>"><?php echo e(__('Exercise')); ?><div class="float-end"><i class="ti ti-chevron-right"></i></div></a>

        <a href="<?php echo e(route('weight.index', ['company_name' => $companyName, 'employee_name' => $employeeName])); ?>" class="list-group-item list-group-item-action border-0 <?php echo e((Request::route()->getName() == 'weight.index' ) ? ' active' : ''); ?>"><?php echo e(__('Weight')); ?><div class="float-end"><i class="ti ti-chevron-right"></i></div></a>

        <a href="<?php echo e(route('sleep.index', ['company_name' => $companyName, 'employee_name' => $employeeName])); ?>" class="list-group-item list-group-item-action border-0 <?php echo e((Request::route()->getName() == 'sleep.index' ) ? ' active' : ''); ?>"><?php echo e(__('Sleep')); ?><div class="float-end"><i class="ti ti-chevron-right"></i></div></a>
    </div>
</div>
<?php /**PATH E:\www\tongle\resources\views\layouts\health_setup.blade.php ENDPATH**/ ?>