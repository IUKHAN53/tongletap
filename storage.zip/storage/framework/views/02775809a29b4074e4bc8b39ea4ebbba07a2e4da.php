<?php echo e($slot); ?>

<?php /**PATH E:\www\tongle\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>