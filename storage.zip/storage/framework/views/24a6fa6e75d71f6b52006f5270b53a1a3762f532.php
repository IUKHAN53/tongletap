<?php echo e(Form::open(['url' => 'ticket', 'method' => 'post'])); ?>

<div class="modal-body">

    <div class="row">
            <div class="form-group">
                <?php echo e(Form::label('title', __('Subject'), ['class' => 'col-form-label'])); ?>

                <?php echo e(Form::text('title', null, ['class' => 'form-control', 'placeholder' => __('Enter Ticket Subject')])); ?>

            </div>
        <!--    <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">-->
        <!--    <div class="form-group">-->
        <!--        <?php echo e(Form::label('CompanyName', __('Company Name'), ['class' => 'col-form-label'])); ?>-->
        <!--        <?php echo e(Form::select('CompanyName', $company, null,['class' => 'form-control select2 company_name', 'placeholder' => __('Company Name')])); ?>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

    <?php if(\Auth::user()->type != 'employee'): ?>
    <div class="row">
        <!--<div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">-->
        <!--    <div class="form-group">-->
        <!--        <?php echo e(Form::label('employee_id', __('Ticket for Employee'), ['class' => 'col-form-label'])); ?>-->
        <!--        <?php echo e(Form::select('employee_id', $employees, null, ['class' => 'form-control select2 employee_id','placeholder' => __('Select Employee')])); ?>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('time_slot', __('Appointment Time and Day'), ['class' => 'col-form-label'])); ?>

                <input type="datetime-local" class="form-control" name="time_slot" id="datetimepicker">
            </div>
        </div>
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('EmployeePhone', __('Employee Phone'), ['class' => 'col-form-label'])); ?>

                <?php echo e(Form::number('EmployeePhone', null, ['class' => 'form-control', 'placeholder' => __('Employee Phone')])); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">
            <div class="form-group">
                <?php echo e(Form::label('priority', __('Priority'), ['class' => 'col-form-label'])); ?>

                <select name="priority" class="form-control select2" id="choices-multiple">
                    <option value="low"><?php echo e(__('Low')); ?></option>
                    <option value="medium"><?php echo e(__('Medium')); ?></option>
                    <option value="high"><?php echo e(__('High')); ?></option>
                    <option value="critical"><?php echo e(__('critical')); ?></option>
                </select>
            </div>
        </div>
    </div>
    <div class="form-group">
        <?php echo e(Form::label('description', __('Description'), ['class' => 'col-form-label'])); ?>

        <?php echo e(Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => __('Ticket Description'),'rows'=>'5'])); ?>

    </div>
</div>
<div class="modal-footer">
    <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">
    <input type="submit" value="<?php echo e(__('Create')); ?>" class="btn  btn-primary">
</div>
<?php echo e(Form::close()); ?><?php /**PATH E:\www\tongle\resources\views\ticket\create.blade.php ENDPATH**/ ?>