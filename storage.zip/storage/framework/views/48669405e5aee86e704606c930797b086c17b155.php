<?php echo e(Form::open(['route' => ['ticket.update-status', $ticket->id], 'method' => 'PUT'])); ?>

<div class="modal-body">
    <div class="form-group">
        <?php echo e(Form::label('status', __('Status'), ['class' => 'col-form-label'])); ?>

        <select name="status" class="form-control  select2" id="status">
            <option value="pending" <?php if($ticket->status == 'pending'): ?> selected <?php endif; ?>><?php echo e(__('Pending')); ?></option>
            <option value="approved" <?php if($ticket->status == 'approved'): ?> selected <?php endif; ?>><?php echo e(__('Approved')); ?></option>
            <option value="rejected" <?php if($ticket->status == 'rejected'): ?> selected <?php endif; ?>><?php echo e(__('Rejected')); ?></option>
        </select>
    </div>
</div>
<div class="modal-footer">
    <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">
    <input type="submit" value="<?php echo e(__('Apply')); ?>" class="btn btn-primary">
</div>
<?php echo e(Form::close()); ?><?php /**PATH E:\www\tongle\resources\views/ticket/edit-status.blade.php ENDPATH**/ ?>