<?php echo e(Form::model($meeting,array('route' => array('meeting.update', $meeting->id), 'method' => 'PUT'))); ?>

<div class="modal-body">
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <?php echo e(Form::label('title',__('Meeting Title'),['class'=>'form-label'])); ?>

                <?php echo e(Form::text('title',null,array('class'=>'form-control','placeholder'=>__('Enter Meeting Title')))); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('date',__('Meeting Date'),['class'=>'form-label'])); ?>

                <?php echo e(Form::date('date',null,array('class'=>'form-control '))); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('time',__('Meeting Time'),['class'=>'form-label'])); ?>

                <?php echo e(Form::time('time',null,array('class'=>'form-control timepicker'))); ?>

            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <?php echo e(Form::label('note',__('Meeting Note'),['class'=>'form-label'])); ?>

                <?php echo e(Form::textarea('note',null,array('class'=>'form-control','placeholder'=>__('Enter Meeting Note')))); ?>

            </div>
        </div>

    </div>
</div>
<div class="modal-footer">
    <input type="button" value="<?php echo e(__('Cancel')); ?>" class="btn  btn-light" data-bs-dismiss="modal">
    <input type="submit" value="<?php echo e(__('Update')); ?>" class="btn  btn-primary">
</div>
<?php echo e(Form::close()); ?>


<?php /**PATH E:\www\tongle\resources\views\meeting\edit.blade.php ENDPATH**/ ?>