<?php echo e(Form::model($overtime,array('route' => array('overtime.update', $overtime->id), 'method' => 'PUT'))); ?>

<div class="modal-body">

    <div class="card-body p-0">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('title', __('Title'),['class'=>'form-label'])); ?>

                    <?php echo e(Form::text('title',null, array('class' => 'form-control ','required'=>'required'))); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('number_of_days', __('Number Of Days'),['class'=>'form-label'])); ?>

                    <?php echo e(Form::text('number_of_days',null, array('class' => 'form-control ','required'=>'required'))); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('hours', __('Hours'),['class'=>'form-label'])); ?>

                    <?php echo e(Form::text('hours',null, array('class' => 'form-control ','required'=>'required'))); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('rate', __('Rate'),['class'=>'form-label'])); ?>

                    <?php echo e(Form::number('rate',null, array('class' => 'form-control ','required'=>'required'))); ?>

                </div>
            </div>
        </div>

    </div>
</div>
<div class="modal-footer">
    <input type="button" value="<?php echo e(__('Cancel')); ?>" class="btn  btn-light" data-bs-dismiss="modal">
    <input type="submit" value="<?php echo e(__('Update')); ?>" class="btn  btn-primary">
</div>
<?php echo e(Form::close()); ?>



<?php /**PATH E:\www\tongle\resources\views\overtime\edit.blade.php ENDPATH**/ ?>