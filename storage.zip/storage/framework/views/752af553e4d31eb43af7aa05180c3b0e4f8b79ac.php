
<div class="modal-body">

    <div class="form-group">
        <label class="form-label" for="exampleFormControlTextarea1"><?php echo e(__('Description')); ?></label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="10" readonly><?php echo e($contract->description); ?></textarea>
    </div>

</div>






<?php /**PATH E:\www\tongle\resources\views\contract\description.blade.php ENDPATH**/ ?>