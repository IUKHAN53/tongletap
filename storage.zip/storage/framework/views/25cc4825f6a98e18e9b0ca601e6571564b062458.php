<?php $__env->startSection('page-title'); ?>
<?php echo e(__('List of Companies')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
<li class="breadcrumb-item"><?php echo e(__('List of companies')); ?></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
    <?php echo e(Form::open(array('url' => 'health', 'method' => 'GET'))); ?>

        <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <?php echo e(Form::label('company_name', __('Company Name'), ['class' => 'col-form-label'])); ?>

                <?php echo e(Form::select('company_name', $companyname, null, ['class' => 'form-control select2 company_name','placeholder' => __('Select Company')])); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <?php echo e(Form::label('employee_name', __('employee Name'), ['class' => 'col-form-label'])); ?>

                <?php echo e(Form::select('employee_name', $employees, null, ['class' => 'form-control select2 employee_name','placeholder' => __('Select employee')])); ?>

            </div>
        </div>
    </div>
    <input type="submit" value="<?php echo e(__('Search')); ?>" class="btn  btn-primary">
    <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tongle\resources\views\health\companies.blade.php ENDPATH**/ ?>