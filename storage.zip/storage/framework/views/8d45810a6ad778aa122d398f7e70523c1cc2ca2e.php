<html>
<head>
<title>Merchant Check Out Page</title>
</head>
<body>
	<br>
	<br>
	<center><h1>Your transaction is being processed!!!</h1></center>
	<center><h2>Please do not refresh this page...</h2></center>
	<?php echo $__env->yieldContent('payment_redirect'); ?>
</body>
</html><?php /**PATH E:\www\tongle\vendor\anandsiddharth\laravel-paytm-wallet\src\resources\views\transact.blade.php ENDPATH**/ ?>